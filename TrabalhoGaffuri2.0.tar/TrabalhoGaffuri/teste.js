function toggleForms() {
  document.getElementById("loginForm").classList.toggle("active");
  document.getElementById("signupForm").classList.toggle("active");
}

// Easter Egg "obs aparece dps de 5 cliques no avatar."
let clickCount = 0;
let activated = false;
const avatar = document.getElementById("avatar");
const easterEgg = document.getElementById("easterEgg");

avatar.addEventListener("click", () => {
  if (activated) return;
  clickCount++;
  if (clickCount === 5) {
    easterEgg.style.display = "block";
    activated = true;
  }
});
// Modo Escuro
const toggleDarkModeBtn = document.getElementById("toggleDarkMode");
toggleDarkModeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");

// Atualiza o ícone do botão
  if (document.body.classList.contains("dark-mode")) {
    toggleDarkModeBtn.textContent = "Modo Claro";
  } else {
    toggleDarkModeBtn.textContent = "Modo Escuro";
  }
});